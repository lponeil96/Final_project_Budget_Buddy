import tkinter as tk
from tkinter import messagebox
from tkinter import filedialog
from PIL import Image, ImageTk
import os

# Function to validate numerical input
def validate_amount(amount):
    try:
        float(amount)
        return True
    except ValueError:
        return False

# Function to create the main window
def create_main_window():
    main_window = tk.Tk()
    main_window.title("Budget Buddy")

    # Allow resizing of the window
    main_window.geometry("500x500")  # Initial size
    main_window.resizable(True, True)  # Allow resizing in both directions

    # Load and display an image
    img = Image.open("budget_icon.png")
    img = img.resize((100, 100))
    img = ImageTk.PhotoImage(img)
    img_label = tk.Label(main_window, image=img, text="Budget Icon", compound=tk.TOP)
    img_label.image = img  # Keep a reference to avoid garbage collection
    img_label.grid(row=0, column=0, columnspan=2, pady=10)

    # Create and pack labels
    label1 = tk.Label(main_window, text="Welcome to Budget Tracker!")
    label1.grid(row=1, column=0, columnspan=2, pady=5)

    label2 = tk.Label(main_window, text="Enter your expense details below.")
    label2.grid(row=2, column=0, columnspan=2, pady=5)

    label3 = tk.Label(main_window, text="Amount and Description:")
    label3.grid(row=3, column=0, columnspan=2, pady=5)

    # Entry widgets for user input
    amount_label = tk.Label(main_window, text="Amount:")
    amount_label.grid(row=4, column=0, padx=10, sticky='e')
    amount_entry = tk.Entry(main_window)
    amount_entry.grid(row=4, column=1, padx=10, pady=5, sticky='w')

    description_label = tk.Label(main_window, text="Description:")
    description_label.grid(row=5, column=0, padx=10, sticky='e')
    description_entry = tk.Entry(main_window)
    description_entry.grid(row=5, column=1, padx=10, pady=5, sticky='w')

    # Buttons
    btn_add = tk.Button(main_window, text="Add Expense", command=lambda: add_expense(amount_entry.get(), description_entry.get()))
    btn_add.grid(row=6, column=0, padx=10, pady=10, sticky='ew')

    btn_view = tk.Button(main_window, text="View Expenses", command=lambda: open_view_window(main_window))
    btn_view.grid(row=6, column=1, padx=10, pady=10, sticky='ew')

    btn_exit = tk.Button(main_window, text="Exit", command=main_window.quit)
    btn_exit.grid(row=7, column=0, columnspan=2, pady=10)

    main_window.mainloop()

# Function to create the view expenses window
def open_view_window(parent_window):
    view_window = tk.Toplevel(parent_window)
    view_window.title("View Expenses")

    # Allow resizing of the window
    view_window.geometry("600x600")  # Initial size
    view_window.resizable(True, True)  # Allow resizing in both directions

    # Load and display an image
    img = Image.open("expenses_icon.png")
    img = img.resize((100, 100))
    img = ImageTk.PhotoImage(img)
    img_label = tk.Label(view_window, image=img, text="Expenses Icon", compound=tk.TOP)
    img_label.image = img  # Keep a reference to avoid garbage collection
    img_label.grid(row=0, column=0, columnspan=2, pady=10)

    # Create and pack labels
    label1 = tk.Label(view_window, text="Expenses Summary")
    label1.grid(row=1, column=0, columnspan=2, pady=5)

    # Display the expenses list
    expenses_text = tk.Text(view_window, height=10, width=70)
    expenses_text.grid(row=2, column=0, columnspan=2, padx=10, pady=5, sticky='nsew')
    expenses_text.insert(tk.END, get_expenses_summary())

    # Create buttons to delete an item and close the view window
    tk.Label(view_window, text="Enter description to delete:").grid(row=3, column=0, padx=10, pady=5, sticky='e')
    delete_entry = tk.Entry(view_window)
    delete_entry.grid(row=3, column=1, padx=10, pady=5, sticky='w')

    btn_delete = tk.Button(view_window, text="Delete Expense", command=lambda: delete_expense(delete_entry.get(), expenses_text))
    btn_delete.grid(row=4, column=0, columnspan=2, pady=5)

    btn_close = tk.Button(view_window, text="Close", command=view_window.destroy)
    btn_close.grid(row=5, column=0, columnspan=2, pady=5)

    # Update total amount spent
    total_label = tk.Label(view_window, text=f"Total Spent: ${get_total_expenses():.2f}")
    total_label.grid(row=6, column=0, columnspan=2, pady=5)

# Function to add an expense
def add_expense(amount, description):
    if not amount or not description:
        messagebox.showerror("Input Error", "Both amount and description are required.")
        return

    if not validate_amount(amount):
        messagebox.showerror("Input Error", "Invalid amount. Please enter a numeric value.")
        return

    try:
        with open("expenses.txt", "a") as file:
            file.write(f"{amount}\t{description}\n")
        messagebox.showinfo("Success", "Expense added successfully.")
    except IOError:
        messagebox.showerror("File Error", "Could not write to file.")

# Function to get the summary of expenses
def get_expenses_summary():
    if not os.path.exists("expenses.txt"):
        return "No expenses recorded yet."

    with open("expenses.txt", "r") as file:
        return file.read()

# Function to get the total of expenses
def get_total_expenses():
    if not os.path.exists("expenses.txt"):
        return 0.0

    total = 0.0
    with open("expenses.txt", "r") as file:
        for line in file:
            parts = line.split('\t')
            if parts[0].replace('.', '', 1).isdigit():  # Check if the amount is numeric
                total += float(parts[0])
    return total

# Function to delete an expense by description
def delete_expense(description, text_widget):
    if not description:
        messagebox.showerror("Input Error", "Description is required.")
        return

    try:
        lines = []
        with open("expenses.txt", "r") as file:
            lines = file.readlines()

        with open("expenses.txt", "w") as file:
            found = False
            for line in lines:
                if description in line:
                    found = True
                else:
                    file.write(line)

        if found:
            messagebox.showinfo("Success", "Expense deleted successfully.")
            text_widget.delete(1.0, tk.END)  # Clear and reload text widget
            text_widget.insert(tk.END, get_expenses_summary())
            total_label = tk.Label(text_widget.master, text=f"Total Spent: ${get_total_expenses():.2f}")
            total_label.grid(row=6, column=0, columnspan=2, pady=5)
        else:
            messagebox.showerror("Delete Error", "No expense found with the given description.")
    except IOError:
        messagebox.showerror("File Error", "Could not read or write to file.")

# Entry point of the application
if __name__ == "__main__":
    create_main_window()
